$('body')
        .scrollTop(0,1);
(function(){
    "use strict";
    angular.module('app',
            [
                'ionic',
                'toaster'////,
                        //    'ngStorage',
                        //    'ngCordova'
            ]);
})();

