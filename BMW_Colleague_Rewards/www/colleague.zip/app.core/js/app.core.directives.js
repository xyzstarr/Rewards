(function () {
    "use strict";
})();